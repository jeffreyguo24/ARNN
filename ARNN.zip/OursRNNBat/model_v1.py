import torch.nn as nn
from torch.autograd import Variable
import torch
import torch.nn.functional as F
from torch.nn.utils.rnn import pack_padded_sequence, pad_packed_sequence


class Attn(nn.Module):
    def __init__(self, method, hidden_size):
        super(Attn, self).__init__()

        self.method = method
        self.hidden_size = hidden_size

        if self.method == 'general':
            self.attn = nn.Linear(self.hidden_size, hidden_size)

        elif self.method == 'concat':
            self.attn = nn.Linear(self.hidden_size * 2, hidden_size)
            self.v = nn.Parameter(torch.FloatTensor(hidden_size))

    def forward(self, hidden, encoder_outputs):
        seq_len = encoder_outputs.size(0)
        batch_size = encoder_outputs.size(1)
#         print('[attn] seq len', seq_len)
#         print('[attn] encoder_outputs', encoder_outputs.size()) # S x B x N
#         print('[attn] hidden', hidden.size()) # S=1 x B x N

        # Create variable to store attention energies
        attn_energies = Variable(torch.zeros(batch_size, seq_len)) # B x S
#         print('[attn] attn_energies', attn_energies.size())

        if torch.cuda.is_available():
            attn_energies = attn_energies.cuda()

        # For each batch of encoder outputs
        for b in range(batch_size):
            # Calculate energy for each encoder output
            for i in range(seq_len):
                attn_energies[b, i] = self.score(hidden[:, b], encoder_outputs[i, b].unsqueeze(0))

        # Normalize energies to weights in range 0 to 1, resize to 1 x B x S
#         print('[attn] attn_energies', attn_energies.size())
        return F.softmax(attn_energies, dim=1).unsqueeze(1)

    def score(self, hidden, encoder_output):

        if self.method == 'dot':
            energy = hidden.dot(encoder_output)
            return energy

        elif self.method == 'general':
            energy = self.attn(encoder_output)
            energy = hidden.dot(energy)
            return energy

        elif self.method == 'concat':
            # print("hidden type", hidden.type(), encoder_output.type())
            energy = self.attn(torch.cat((hidden, encoder_output), 1))
            energy = energy.squeeze(0)
            # print("energy size, v size:", energy.size(), self.v.size())
            energy = self.v.dot(energy)
            return energy


class RecurrentNet(nn.Module):
    def __init__(self, rnn_type, n_users, n_hours, n_cates, input_size, embed_size, hidden_size, output_size, batch_size, \
                 n_layers=1, batch_first=False, nonlinearity = 'relu', dropout=0.5):
        super(RecurrentNet, self).__init__()

        self.embed_size = embed_size
        self.hidden_size = hidden_size
        self.batch_size = batch_size
        self.type = rnn_type

        self.user_embed = nn.Embedding(n_users, embed_size)
        self.hour_embed = nn.Embedding(n_hours, embed_size)
        self.poi_embed  = nn.Embedding(input_size, embed_size)
        self.cate_embed = nn.Embedding(n_cates, embed_size)

        self.attn = Attn("concat", self.embed_size)

        if self.type =='LSTM':
            self.rnn = nn.LSTM(embed_size, hidden_size, n_layers, nonlinearity=nonlinearity, dropout=dropout)
        elif self.type == 'GRU':
            self.rnn = nn.GRU(embed_size, hidden_size, n_layers, nonlinearity=nonlinearity, dropout=dropout)
        elif self.type == 'RNN':
            self.rnn = nn.RNN(embed_size, hidden_size, n_layers, nonlinearity=nonlinearity, dropout=dropout)
        
        self.linear1 = nn.Linear(embed_size*3, embed_size)
        self.linear2 = nn.Linear(embed_size, output_size)
        self.linear3 = nn.Linear(embed_size*2, embed_size)
        self.decoder = nn.Linear(hidden_size, output_size)
        self.softmax = nn.LogSoftmax(dim=1)

    def forward(self, user_tensor, hour_tensor, poi_tensor, cate_tensor, nbr_tensor, sorted_length):
        """user_tensor: seq_len(max_len) * batch_size (the element indicate the idx)
           embed_user:  seq_len(max_len) * batch_size * embed_size
           the seq_len of all kinds of tensors should be the same: longest length of all sequences

           refer to https://pytorch.org/docs/master/nn.html#torch.nn.utils.rnn.pack_padded_sequence
           the input of pack_padded_sequence: seq_len * batch_size * embed_size if batch_first is false
        """ 
        embed_user = self.user_embed(user_tensor) # seq_len * batch_size * embed_size 
        embed_poi  = self.poi_embed(poi_tensor)
        embed_cate = self.cate_embed(cate_tensor)
        embed_hour = self.hour_embed(hour_tensor)


        """
        find neighbors 
        poi_tensor: max_len x batch_size x embed_size
        the length is already sorted, so the first seq of poi_tensor[:, 0, :] is max_len

        
        t_embed_list = max_len x batch_size x embed_size
        max_len  = poi_tensor.size()[0]
        for t in range(max_len):
            attn_weights = self.attn(t_embed, alistofembeddings)
            context = attn_weights.bmm(alistofembeddings)
            t_embed = F.tanh(self.linear3(torch.cat(t_embed, context)))
            put t_embed into t_embed_list
        """
        max_len, batch_size = poi_tensor.size()[0], poi_tensor.size()[1]
        n_nbrs  = nbr_tensor.size()[2] # max_len x batch_size x n_nbrs
        embed_pois = Variable(torch.zeros(max_len, batch_size, self.embed_size))

        for t in range(max_len):
            # print("t", t)
            t_embed_poi = embed_poi[t] # batch_size x embed_size
            t_embed_poi = t_embed_poi.unsqueeze(0)
            # print("t_embed_poi:", t_embed_poi.size())
            t_embed_nbrs = Variable(torch.zeros(n_nbrs, batch_size, self.embed_size))
            # now get the nbr_tensor
            for n in range(n_nbrs):
                embed_nbr = self.poi_embed(nbr_tensor[t, :, n]) # size: batch_size x embed_size
                # if n == 1:
                #     print("embed_nbr:", embed_nbr.size())
                t_embed_nbrs[n, :, :] = embed_nbr
            # print("t_embed_nbrs:", t_embed_nbrs.size())
            if torch.cuda.is_available():
                t_embed_nbrs = t_embed_nbrs.cuda()
            attn_weights = self.attn(t_embed_poi, t_embed_nbrs)
            context = attn_weights.bmm(t_embed_nbrs.transpose(0, 1)) # context: batch_size x 1 x embed_size
            context = context.squeeze(1) # context: batch_size x embed_size
            t_embed_poi = t_embed_poi.squeeze(0) # t_embed_poi: batch_size x embed_size
            concat_embed = torch.cat((t_embed_poi, context), 1)
            concat_embed = F.tanh(self.linear3(concat_embed)) # concat_embed: batch_size x embed_size
            # print("concat_embed size:", concat_embed.size())
            embed_pois[t, :, :] = concat_embed

        # print("user poi cate hour sizes:", embed_user.size(), embed_poi.size(), embed_cate.size(), embed_hour.size())

        # embed_cont = torch.cat((embed_poi, embed_cate, embed_hour), 2)

        if torch.cuda.is_available():
            embed_pois = embed_pois.cuda()
        embed_cont = torch.cat((embed_pois, embed_cate, embed_hour), 2)
        # print("\nembed_cont size:", embed_cont.size())
        embed_cont = self.linear1(embed_cont)

        # print("2embed_cont size:", embed_cont.size())

        # packed_user = pack_padded_sequence(embed_user, sorted_length.tolist())
        # packed_poi  = pack_padded_sequence(embed_poi,  sorted_length.tolist())
        # packed_cate = pack_padded_sequence(embed_cate, sorted_length.tolist())
        # packed_hour = pack_padded_sequence(embed_hour, sorted_length.tolist())

        packed_cont = pack_padded_sequence(embed_cont, sorted_length.tolist())
        if torch.cuda.is_available():
            packed_cont = packed_cont.cuda()

        # out, hidden = self.rnn(packed_poi)
        out, hidden = self.rnn(packed_cont) # hidden: n_layers*n_directions x batch_size x hidden_size
        out, _ = pad_packed_sequence(out) # seq_len * batch_size * output_size
        out = self.decoder(out[-1, :, :]) # only take the output of last step

        user_pref = self.linear2(embed_user)
        # print("out size:", out.size(), user_pref[0,:,:].size(), embed_user.size())
        pref = out + user_pref[0, :, :]
        out = self.softmax(pref)
        return out

    def init_hidden(self):
        if self.type == "LSTM":
            return (Variable(torch.zeros((self.n_layers, self.batch_size, self.hidden_size))),
                             Variable(torch.zeros((self.n_layers, self.batch_size, self.hidden_size))))
        elif self.type in ('GRU', 'RNN'):
            return Variable(torch.zeros((self.n_layers, self.batch_size, self.hidden_size)))
