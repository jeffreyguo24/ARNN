import os
import networkx as nx
import argparse
import numpy
import pickle
import random
import json
from math import pi, sqrt, cos, sin, asin, e
import igraph as ig
import pickle

import para_config

pickle_file = para_config.PICKLE_FILE
nbr_file   = para_config.nbr_file

 
def compute_geodist(lat1, lon1, lat2, lon2):
    rad_lat1 = lat1*pi/180.0
    rad_lat2 = lat2*pi/180.0
    phi = rad_lat1 - rad_lat2
    lambdaa = lon1*pi/180.0 - lon2*pi/180.0
    u = sin(phi/2.0)
    v = sin(lambdaa/2.0)
    s = 2*asin(sqrt(u * u + cos(rad_lat1) * cos(rad_lat2) * v * v))
    return s * 6378.137   


def compute_jaccad(poi_list1, poi_list2):
    common = set([p for p in poi_list1 if p in poi_list2])
    if len(common) == 0:
        return 0.0
    poi_list1.extend(poi_list2)
    return len(common) / float(len(set(poi_list1)))

    
def readTrainData(user_train_trajs, pois, user_index, poi_index, cate_index):
    '''read train file and return user_poi_star_dict
    '''

    index_user_dict = {index: user for user, index in user_index.items()}
    index_poi_dict  = {index: poi  for poi,  index in poi_index.items()}
    index_cate_dict = {index: cate for cate, index in cate_index.items()}

    alluser_list, allpoi_list, allcate_list = [], [], []
    user_poi_list_dict = {}
    for ui in user_train_trajs:
        user = index_user_dict[ui]
        poi_list = []
        for traj in user_train_trajs[ui]:
            for record in traj:
                poi = index_poi_dict[record[2]]
                poi_list.append(poi)
                allpoi_list.append(poi)
        user_poi_list_dict[user] = list(set(poi_list))
    alluser_list = list(user_poi_list_dict.keys())
    allpoi_list  = list(set(allpoi_list))

    # poi_lat_lon_dict = {}
    # poi_cate_list_dict = {}
    # for poi in pois: #14637,34.0430230998,-118.2671570778,Stadium,Concert Hall,Basketball Stadium
    #     if poi not in allpoi_list:
    #         continue
    #     lat  = float(pois[poi][1])
    #     lon  = float(pois[poi][2])
    #     cate_list = [pois[poi][3]]
    #     allcate_list.append(pois[poi][3])
    #     poi_lat_lon_dict[poi] = (lat, lon)
    #     poi_cate_list_dict[poi] = cate_list

    # allcate_list = list(set(allcate_list))

    # poi_poi_list_dict = {}
    # for poi1 in poi_lat_lon_dict:
    #     lat1, lon1 = poi_lat_lon_dict[poi1][0], poi_lat_lon_dict[poi1][1]
    #     for poi2 in poi_lat_lon_dict:
    #         if poi1 == poi2: continue
    #         lat2, lon2 = poi_lat_lon_dict[poi2][0], poi_lat_lon_dict[poi2][1]
    #         distance = compute_geodist(lat1, lon1, lat2, lon2)
    #         if distance > 2.0: continue
    #         if poi1 not in poi_poi_list_dict:
    #             poi_poi_list_dict[poi1] = [poi2]
    #         else:
    #             poi_poi_list_dict[poi1].append(poi2)    

    # return user_poi_list_dict, poi_poi_list_dict, poi_cate_list_dict, alluser_list, allpoi_list, allcate_list 
    return allpoi_list


def get_poi_pr_dict_nx(G, targetType, topK, pr_file, user_list, poi_list, cate_list, poi_poi_list_dict, \
                       user_poi_list_dict, poi_cate_list_dict, poi_index):
    '''construct graph from train and friends datastet
    ''' 

    allNodes = list(G.nodes())
    node_type_dict = nx.get_node_attributes(G, 'type')
    targetNodes = [n for n in allNodes if node_type_dict[n] == 'p']
    print("the number of pois:", len(targetNodes))
    personalization = {n: 0 for n in allNodes}
    node_nbr_list_dict, node_nbr_pr_list_dict = {}, {}
    for n in targetNodes:
        print("pagerank for:", n)
        node_nbr_list_dict[n], node_nbr_pr_list_dict[n] = [], []
        personalization[n] = 1.0
        pr_dict = nx.pagerank(G, personalization=personalization)
        sorted_pr_list = sorted(pr_dict.items(), key = lambda x:x[1], reverse = True)  
        for entity, score in sorted_pr_list:
            if entity in targetNodes:
                if entity == n: continue
                node_nbr_list_dict[n].append(entity)
                node_nbr_pr_list_dict[n].append((entity, score))
        node_nbr_list_dict[n] = node_nbr_list_dict[n][:topK]
        personalization = {n: 0 for n in allNodes}

    if not os.path.exists(pr_file):
        pickle.dump(node_nbr_list_dict, open(pr_file, 'wb'))

    return node_nbr_list_dict


def get_poi_pr_dict_ig(targetType, topK, pr_file, user_list, poi_list, cate_list, poi_poi_list_dict, \
                       user_poi_list_dict, poi_cate_list_dict, poi_index):
    '''construct graph from train and friends datastet
    ''' 

    G = ig.Graph(directed=False)
    vertices = []
    for user in user_list:
        vertices.append(user)
    for poi in poi_list:
        vertices.append(poi)
    for cate in cate_list:
        vertices.append(cate)
    G.add_vertices(vertices)

    allNodes = [v['name'] for v in G.vs]

    G.es['weight'] = 1.0 #weighted graph
    edges = []
    for d in (user_poi_list_dict, poi_poi_list_dict, poi_cate_list_dict):
        for n, nbr_list in d.items():
            if n not in allNodes:
                continue
            for nbr in nbr_list:
                if nbr not in allNodes:
                    continue
                edges.append((n, nbr))
    G.add_edges(edges)
    for eid in range(len(edges)):
        G.es[eid]['weight'] = 1.0

    users = [v['name'] for v in G.vs if v['name'] in user_list]
    pois = [v['name'] for v in G.vs if v['name'] in poi_list]

    print("build graph for personalized_pagerank")

    targetNodes = pois
    node_nbr_list_dict = {n:[] for n in targetNodes}
    node_nbr_pr_list_dict = {n:[] for n in targetNodes}

    i = 0
    reset = [0 for j in range(len(allNodes))]
    for n in targetNodes:
        if i%100 == 0:
            print("pagerank for:", n, i)
        i += 1
        reset[allNodes.index(n)] = 1.0 # personalization
        pr_list = G.personalized_pagerank(directed=False, reset = reset, weights="weight")
        pr_dict = {}
        for j in range(len(allNodes)):
            pr_dict.setdefault(allNodes[j], pr_list[j])
        sorted_pr_list = sorted(pr_dict.items(), key = lambda x:x[1], reverse = True)  
        # print sorted_pr_list     
        for entity, score in sorted_pr_list:
            if entity in targetNodes:
                if entity == n: continue
                node_nbr_list_dict[n].append(entity)
                node_nbr_pr_list_dict[n].append((entity, score))
        node_nbr_list_dict[n] = node_nbr_list_dict[n][:topK]
        reset = [0 for j in range(len(allNodes))]

    if not os.path.exists(pr_file):
        pickle.dump(node_nbr_list_dict, open(pr_file, 'wb'))
        print("write pr value into ", pr_file)

    return node_nbr_list_dict
    

def extract_neighbors_pr(poi_nbr_list_dict, poi_index):

    poi_nbr_list_dict2 = {}
    for poi in poi_nbr_list_dict:
        pi = poi_index[poi]
        nbr_list = poi_nbr_list_dict[poi]
        poi_nbr_list_dict2[pi] = [poi_index[n] for n in nbr_list]
    return poi_nbr_list_dict2


def construct_graph_nx(user_poi_list_dict, poi_poi_list_dict, poi_cate_list_dict,\
    alluser_list, allpoi_list, allcate_list):
    '''
    build and comput the statistics of the built graph
    number of different edges
    '''
    G = nx.Graph() # networkx will transfer graph into directed graph
    # step1: add nodes
    for user in alluser_list:
        G.add_node(user, type = 'u')
    for poi in allpoi_list:
        G.add_node(poi, type = 'p')
    for cate in allcate_list:
        G.add_node(cate, type = 'c')
    allNodes = list(G.nodes())
    node_type_dict = nx.get_node_attributes(G,'type')

    for d in (user_poi_list_dict, poi_poi_list_dict, poi_cate_list_dict):
        for n, nbr_list in d.items():
            if n not in allNodes:
                continue
            n_type = node_type_dict[n]
            for nbr in nbr_list:
                if nbr not in allNodes:
                    continue
                nbr_type = node_type_dict[nbr]
                G.add_edge(n, nbr)
    print("build Graph")
    return G


def extract_nbrs_from_paths(G, start, paths):
    '''
    extract nbrs from extracted paths
    '''

    node_type_dict = nx.get_node_attributes(G, 'type')
    nbr_list = []
    targetType = node_type_dict[start]
    for path in paths:
        for n in path[1:]:
            if (node_type_dict[n] == targetType) and (n not in nbr_list):
                nbr_list.append(n)
    return nbr_list


def meta_path_random_walk(G, start, new_meta_path, walk_num, path_node_num):
    """ Returns a truncated random walk.
        path_length: Length of the random walk.
        start: the start node of the random walk.
    """

    rand = random.Random()
    node_type_dict = nx.get_node_attributes(G, 'type')
    paths = []
    # pl = path_node_num
    for wn in range(walk_num):
        path = [start] # each walk aims to find a path
        # print "start node is", start
        # print wn
        # t = 1
        # pl -= 1 
        while len(path) < path_node_num:
            cur = path[-1] # random walker is at current node
            step = len(path)
            if len(G[cur]) == 0:
                break  
            else:
                effective_nbrs = [nbr for nbr in list(G[cur]) if node_type_dict[nbr] == new_meta_path[step]]
                for nbr in effective_nbrs:
                    if nbr in path:
                        effective_nbrs.remove(nbr)
                if len(effective_nbrs) == 0:
                    break
                next_node = rand.choice(effective_nbrs)
                # if node_type_dict[next_node] == new_meta_path[t]:
                path.append(next_node)
                # pl -= 1
                # t+= 1 # move forward one step
        if len(path) == path_node_num and path not in paths:
            paths.append(path)
        # print path
        # print [node_type_dict[n] for n in path]
        # print len([node_type_dict[n] for n in path])
        # pl = path_node_num    
    return paths


def extract_nbrs_from_metapaths(G, pr_dict, topK, walk_num, targetType, nbrs_file, metaPath_list, seq_len, poi_index):
    '''
    extract nbrs from selected metapaths
    '''

    node_type_dict = nx.get_node_attributes(G, 'type')
    targetNodes = [n for n in G.nodes() if node_type_dict[n]==targetType]
    print("targetType and the number of targetNodes:", targetType, len(targetNodes))
    poi_metaPath_nbrs_dict = {node:{mp:[] for mp in metaPath_list} for node in targetNodes}
    poi_allNbrs_dict = {node:[] for node in targetNodes}

    poi_metaPath_nbrs_dict2 = {poi_index[node]:{mp:[] for mp in metaPath_list} for node in targetNodes}
    poi_allNbrs_dict2 = {poi_index[node]:[] for node in targetNodes}

    for meta_path in metaPath_list:
        meta_path_length = len(meta_path) - 1
        path_length = meta_path_length * seq_len
        path_node_num = path_length + 1
        new_meta_path = meta_path
        for m in range(100):
            new_meta_path += meta_path[1:]

        i = 0
        for start in targetNodes:
            print(start)
            i += 1
            if i % 500 == 0: print(i, start)
            # if start not in pr_dict: continue

            paths = meta_path_random_walk(G, start, new_meta_path, walk_num, path_node_num)
            nbr_list = extract_nbrs_from_paths(G, start, paths)

            # print "walk num and number of nbrs:", walk_num, len(nbr_list)
            # poi_metaPath_nbrs_dict[start][meta_path] = [n for n in nbr_list if n in pr_dict[start][:topK]]
            # poi_allNbrs_dict[start].extend([n for n in nbr_list if n in pr_dict[start][:topK]])

            poi_allNbrs_dict[start].extend(nbr_list)

            # for n in nbr_list:
            #     print(node_type_dict[n]) 
            #     print(n, poi_index[n])

            # poi_metaPath_nbrs_dict2[poi_index[start]][meta_path] = \
            #                         [poi_index[n] for n in nbr_list if n in pr_dict[start][:topK]]
            # poi_allNbrs_dict2[poi_index[start]].extend([poi_index[n] for n in nbr_list if n in pr_dict[start][:topK]])

            poi_allNbrs_dict2[poi_index[start]].extend([poi_index[n] for n in nbr_list])

    for node, allNbrs in poi_allNbrs_dict.items():
        poi_allNbrs_dict[node] = set(allNbrs)

    for node, allNbrs in poi_allNbrs_dict2.items():
        poi_allNbrs_dict2[node] = set(allNbrs)
    print("walk num, avg number of nbrs:", walk_num, \
           sum([len(poi_allNbrs_dict[n]) for n in targetNodes]) / float(len(targetNodes)),\
           sum([len(poi_allNbrs_dict2[poi_index[n]]) for n in targetNodes]) / float(len(targetNodes)))

    # pickle.dump((poi_metaPath_nbrs_dict2, poi_allNbrs_dict2), open(nbrs_file, 'wb'))
    pickle.dump(poi_allNbrs_dict2, open(nbrs_file, 'wb'))
    print("write poi_allNbrs_dict to", nbrs_file)


def find_user_nbrs(user_poi_list_dict, n_nbrs, user_index):
    '''find neighbors for each user
    '''

    user_poi_list_dict = {user_index[user]:user_poi_list_dict[user] for user in user_poi_list_dict}
    user_nbrs_dict = {}
    users = list(user_poi_list_dict.keys())
    user_user_sim_dict = {user:{} for user in users}
    i = 0
    computed_users = []
    for user1 in users:
        print("user:", i)
        i += 1
        poi_list1 = user_poi_list_dict[user1]
        for user2 in users:
            if user1 == user2: continue
            if user2 in computed_users:
                sim = user_user_sim_dict[user2][user1]
            else:
                poi_list2 = user_poi_list_dict[user2]
                sim = compute_jaccad(poi_list1, poi_list2)
            user_user_sim_dict[user1][user2] = sim
        computed_users.append(user1)

    user_user_sim_dict = {user:user_user_sim_dict[user].items() for user in user_user_sim_dict}
    for user in users:
        user_sim_list = user_user_sim_dict[user]
        sort_list = sorted(user_sim_list, key=lambda x:x[1], reverse=True)
        user_nbrs_dict[user] = [x[0] for x in sort_list[:n_nbrs]]

    return user_nbrs_dict


def main():
    data = 'fs'
    city = 'ny'
    if data == 'fs':
        dir_path = '../datasets/foursquare_' + city
        poi_file = os.path.join(dir_path, 'venues.txt')
    else:
        dir_path = '../datasets/gowalla_' + city
        poi_file = os.path.join(dir_path, 'venues.txt')

    print("pickle_file:", pickle_file)
    # save the nbrs
    poi_nbrs_file = nbr_file

    with (open(pickle_file, 'rb')) as fp:
        user_all_trajs, user_train_trajs, user_test_trajs, \
            pois, user_index, poi_index, cate_index = pickle.load(fp)
    
    # user_poi_list_dict, poi_poi_list_dict, poi_cate_list_dict, alluser_list, allpoi_list, allcate_list = \
    #             readTrainData(user_all_trajs, pois, user_index, poi_index, cate_index) 

    allpoi_list = readTrainData(user_all_trajs, pois, user_index, poi_index, cate_index)

    print("read data") 


    # user_nbr_file = os.path.join(dir_path, 'user_nbr_file.pkl')
    # user_nbrs_dict = find_user_nbrs(user_poi_list_dict, 30, user_index)
    # pickle.dump(user_nbrs_dict, open(user_nbr_file, 'wb'))
    # print("test:", user_nbrs_dict.items())

    # poi_pr_file = os.path.join(dir_path, 'poi_pr_file_12.pkl')

    # topK = 50
    # if not os.path.exists(poi_pr_file):
    #     print("poi pr file doesn't exist")
    #     poi_poi_pr_dict = get_poi_pr_dict_ig('p', topK, poi_pr_file, alluser_list, allpoi_list, \
    #                                 allcate_list, poi_poi_list_dict, user_poi_list_dict, poi_cate_list_dict, poi_index)
    # else:
    #     with (open(poi_pr_file, "rb")) as fp:
    #         poi_poi_pr_dict = pickle.load(fp)
    
    # try:
    #     print("test: ", len(poi_poi_pr_dict['4b64b7f0f964a520caca2ae3']))
    # except:
    #     pass

    # for poi in poi_poi_pr_dict:
    #     if len(poi_poi_pr_dict[poi]) != 50:
    #         print("len != 50")

    # poi_nbr_list_dict = extract_neighbors_pr(poi_poi_pr_dict, poi_index)
    # pickle.dump(poi_nbr_list_dict, open(poi_nbrs_file, 'wb'))
    # extract neighbors by only use pagerank value


    # extract neighbors
    # G = construct_graph_nx(user_poi_list_dict, poi_poi_list_dict, poi_cate_list_dict,\
                           # alluser_list, allpoi_list, allcate_list)

    print("construct the graph")

    import random
    poi_metaPath_list = ['pup', 'pcp', 'pp']
    walk_num, topK, seq_len = 20, 20, 1
    # extract_nbrs_from_metapaths(G, poi_poi_pr_dict, topK, walk_num, 'p', poi_nbrs_file, poi_metaPath_list, seq_len, poi_index)

    poi_allNbrs_dict = {}
    for poi in allpoi_list:
        print(poi)
        poi_allNbrs_dict[poi_index[poi]] = [poi_index[n] for n in random.sample(allpoi_list, topK)]

    pickle.dump(poi_allNbrs_dict, open(poi_nbrs_file, 'wb'))


    # poi_metaPath_nbrs_dict, poi_nbrs_dict = pickle.load(open(poi_nbrs_file, 'rb'))
    # print("test poi_nbrs_dict:", len(poi_nbrs_dict), poi_nbrs_dict[0])

    # k = 0
    # for p in poi_nbrs_dict:
    #     if len(poi_nbrs_dict[p]) < 1:
    #         print(p, poi_nbrs_dict[p])
    #         k+=1
    # print(k)

    print("finish extract neighbors")


if __name__ == '__main__':
    main()
